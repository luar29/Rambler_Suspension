#include "ros/ros.h"
#include "std_msgs/Float64.h"
#include "std_msgs/Int16.h"

class Float64ToInt16Converter
{
public:
  Float64ToInt16Converter()
  {
    // Initialize ROS node handle
    ros::NodeHandle nh;

    // Subscribe to the topics publishing Float64 messages
    sub_front_left = nh.subscribe("/front_left/output", 1000, &Float64ToInt16Converter::float64CallbackFrontLeft, this);
    sub_front_right = nh.subscribe("/front_right/output", 1000, &Float64ToInt16Converter::float64CallbackFrontRight, this);
    sub_rear_left = nh.subscribe("/rear_left/output", 1000, &Float64ToInt16Converter::float64CallbackRearLeft, this);
    sub_rear_right = nh.subscribe("/rear_right/output", 1000, &Float64ToInt16Converter::float64CallbackRearRight, this);

    // Advertise on the topics to publish Int16 messages
    pub_front_left =
        nh.advertise<std_msgs::Int16>("/device22/set_write_analogue_outputs_16_bit/write_analogue_output_3", 1);
    pub_front_right =
        nh.advertise<std_msgs::Int16>("/device21/set_write_analogue_outputs_16_bit/write_analogue_output_3", 1);
    pub_rear_left =
        nh.advertise<std_msgs::Int16>("/device22/set_write_analogue_outputs_16_bit/write_analogue_output_1", 1);
    pub_rear_right =
        nh.advertise<std_msgs::Int16>("/device21/set_write_analogue_outputs_16_bit/write_analogue_output_1", 1);
  }

  void float64CallbackFrontLeft(const std_msgs::Float64::ConstPtr &msg)
  {
    convertAndPublish(msg, pub_front_left);
  }

  void float64CallbackFrontRight(const std_msgs::Float64::ConstPtr &msg)
  {
    convertAndPublish(msg, pub_front_right);
  }

  void float64CallbackRearLeft(const std_msgs::Float64::ConstPtr &msg)
  {
    convertAndPublish(msg, pub_rear_left);
  }

  void float64CallbackRearRight(const std_msgs::Float64::ConstPtr &msg)
  {
    convertAndPublish(msg, pub_rear_right);
  }

private:
  void convertAndPublish(const std_msgs::Float64::ConstPtr &msg, ros::Publisher &pub)
  {
    // Convert the received Float64 value to Int16
    int16_t int16_value = static_cast<int16_t>(msg->data);

    // Create an Int16 message and publish it
    std_msgs::Int16 int16_msg;
    int16_msg.data = int16_value;
    pub.publish(int16_msg);
  }

  ros::Subscriber sub_front_left;
  ros::Subscriber sub_front_right;
  ros::Subscriber sub_rear_left;
  ros::Subscriber sub_rear_right;

  ros::Publisher pub_front_left;
  ros::Publisher pub_front_right;
  ros::Publisher pub_rear_left;
  ros::Publisher pub_rear_right;
};

int main(int argc, char **argv)
{
  // Initialize ROS node
  ros::init(argc, argv, "float64_to_int16_converter");

  // Create an instance of Float64ToInt16Converter class
  Float64ToInt16Converter converter;

  // Spin
  ros::spin();

  return 0;
}

