/*
 * Copyright (c) 2015-2016, Thomas Keh
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *    1. Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *    2. Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *
 *    3. Neither the name of the copyright holder nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

#include "bridge.h"
#include "entry_publisher.h"
#include "entry_subscriber.h"
#include "logger.h"

#include <chrono>
#include <memory>
#include <thread>

int main(int argc, char *argv[])
{
  // Set the name of your CAN bus. "slcan0" is a common bus name
  // for the first SocketCAN device on a Linux system.
  const std::string busname = "can0";

  // Set the baudrate of your CAN bus. Most drivers support the values
  // "1M", "500K", "125K", "100K", "50K", "20K", "10K" and "5K".
  const std::string baudrate = "1M";

  kaco::Master master;
  if (!master.start(busname, baudrate))
  {
    ERROR("Starting master failed.");
    return EXIT_FAILURE;
  }

  std::this_thread::sleep_for(std::chrono::seconds(1));

  if (master.num_devices() < 1)
  {
    ERROR("No devices found.");
    return EXIT_FAILURE;
  }

  // should be a 406 device

  // Encoder 1
  kaco::Device &device1 = master.get_device(2);
  device1.start();
  device1.load_dictionary_from_library();
  //	uint16_t profile1 = device1.get_device_profile_number();

  // Encoder 2
  kaco::Device &device2 = master.get_device(3);
  device2.start();
  device2.load_dictionary_from_library();
  //	uint16_t profile2 = device2.get_device_profile_number();

  // Encoder 3

  kaco::Device &device3 = master.get_device(4);
  device3.start();
  device3.load_dictionary_from_library();
  //	uint16_t profile3 = device3.get_device_profile_number();

  // Encoder 4

  kaco::Device &device4 = master.get_device(5);
  device4.start();
  device4.load_dictionary_from_library();
  // uint16_t profile4 = device4.get_device_profile_number();

  // if (profile != 406) {
  //	ERROR("This example is intended for use with a CiA 406 device. You plugged a device with profile number
  //"<<std::dec<<profile); 	return EXIT_FAILURE;
  //}

  // device.print_dictionary();

  // map PDOs (optional)
  device1.add_receive_pdo_mapping(0x1800, "Position Value", 0); // offset 0
  device2.add_receive_pdo_mapping(0x1800, "Position Value", 0); // offset 0
  device3.add_receive_pdo_mapping(0x1800, "Position Value", 0); // offset 0
  device4.add_receive_pdo_mapping(0x1800, "Position Value", 0); // offset 0

  ros::init(argc, argv, "encoder");
  ros::NodeHandle n;
  // Create bridge
  kaco::Bridge bridge;

  // create a publisher for reading second 8-bit input and add it to the bridge
  // communication via POD
  // publishing rate = 10 Hz
  auto iopub1 = std::make_shared<kaco::EntryPublisher>(device1, "Position Value");
  bridge.add_publisher(iopub1, 50);
  auto iopub2 = std::make_shared<kaco::EntryPublisher>(device2, "Position Value");
  bridge.add_publisher(iopub2, 50);
  auto iopub3 = std::make_shared<kaco::EntryPublisher>(device3, "Position Value");
  bridge.add_publisher(iopub3, 50);
  auto iopub4 = std::make_shared<kaco::EntryPublisher>(device4, "Position Value");
  bridge.add_publisher(iopub4, 50);

  // run ROS loop

  bridge.run();

  master.stop();
}
