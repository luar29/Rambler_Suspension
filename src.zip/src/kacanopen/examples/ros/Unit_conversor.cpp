
#include <ros/ros.h>
#include <std_msgs/UInt32.h>
#include <std_msgs/Float64.h>
#include <map>

class InterpolatorNode {
public:
    InterpolatorNode() {
        // Initialize ROS node handle
        nh_ = ros::NodeHandle("~");

        // Subscribe to input topics
        sub1_ = nh_.subscribe("/device59/get_position_value", 1, &InterpolatorNode::inputCallback1, this);
        sub2_ = nh_.subscribe("/device60/get_position_value", 1, &InterpolatorNode::inputCallback2, this);
        sub3_ = nh_.subscribe("/device61/get_position_value", 1, &InterpolatorNode::inputCallback3, this);
        sub4_ = nh_.subscribe("/device62/get_position_value", 1, &InterpolatorNode::inputCallback4, this);

        // Advertise output topics
        pub1_ = nh_.advertise<std_msgs::Float64>("/Angulo_convertido_FL", 10);
        pub2_ = nh_.advertise<std_msgs::Float64>("/Angulo_convertido_RL", 10);
        pub3_ = nh_.advertise<std_msgs::Float64>("/Angulo_convertido_RR", 10);
        pub4_ = nh_.advertise<std_msgs::Float64>("/Angulo_convertido_FR", 10);

        // Populate lookup tables
        populateLookupTable(lookup_table1_, input_values1_, output_values1_);
        populateLookupTable(lookup_table2_, input_values2_, output_values2_);
        populateLookupTable(lookup_table3_, input_values3_, output_values3_);
        populateLookupTable(lookup_table4_, input_values4_, output_values4_);
    }

    void inputCallback1(const std_msgs::UInt32::ConstPtr& msg) {
        processInput(msg, pub1_, lookup_table1_);
    }

    void inputCallback2(const std_msgs::UInt32::ConstPtr& msg) {
        processInput(msg, pub2_, lookup_table2_);
    }

    void inputCallback3(const std_msgs::UInt32::ConstPtr& msg) {
        processInput(msg, pub3_, lookup_table3_);
    }

    void inputCallback4(const std_msgs::UInt32::ConstPtr& msg) {
        processInput(msg, pub4_, lookup_table4_);
    }

    void processInput(const std_msgs::UInt32::ConstPtr& msg, ros::Publisher& pub,
                      const std::map<double, double>& lookup_table) {
        // Perform linear interpolation
        double input_value = msg->data;
        double interpolated_value = interpolate(input_value, lookup_table);

        // Ensure the interpolated value is within the range [0, 1]
        interpolated_value = std::max(0.0, std::min(1.0, interpolated_value));

        // Publish the interpolated value
        std_msgs::Float64 output_msg;
        output_msg.data = interpolated_value;
        pub.publish(output_msg);
    }

    void populateLookupTable(std::map<double, double>& lookup_table,
                             const double* input_values, const double* output_values) {
        // Remap the output values to the range [0, 1] based on the scale
        double min_output = output_values[0];
        double max_output = output_values[10];
        double scale_factor = 1.0 / (max_output - min_output);

        // Populate the lookup table with remapped output values
        for (int i = 0; i < 11; ++i) {
            lookup_table[input_values[i]] = (output_values[i] - min_output) * scale_factor;
        }
    }

    double interpolate(double input_value, const std::map<double, double>& lookup_table) {
        // Perform linear interpolation using the lookup table
        auto it = lookup_table.upper_bound(input_value);
        if (it == lookup_table.begin()) {
            return it->second;
        } else if (it == lookup_table.end()) {
            return (--it)->second;
        } else {
            auto lower = std::prev(it);
            double x0 = lower->first;
            double y0 = lower->second;
            double x1 = it->first;
            double y1 = it->second;
            return y0 + (y1 - y0) * (input_value - x0) / (x1 - x0);
        }
    }

private:
    ros::NodeHandle nh_;
    ros::Subscriber sub1_, sub2_, sub3_, sub4_;
    ros::Publisher pub1_, pub2_, pub3_, pub4_;
    std::map<double, double> lookup_table1_, lookup_table2_, lookup_table3_, lookup_table4_;
    double input_values1_[11]  = {8466,8462,8363,8264,8010,7909,7803,7710,7621,7524,7422}; 
    double output_values1_[11] = {43,45,49,55,57.5,60,62.5,65,67.5,70,72.5};
    double input_values4_[11]  = {4312,4315,4463,4565,4855,4970,5093,5202,5310,5425,5542}; 
    double output_values4_[11] = {43,45,49,55,57.5,60,62.5,65,67.5,70,72.5};
    double input_values2_[13]  = {11979,12044,12215,12232,12317,12416,12591,12736,12888,13031,13135,13203,13303};
    double output_values2_[13] = {44.5,46.5,48.5,50.5,52.5,54.5,58.5,61.5,64.5,67.5,69.5,71,72.5};
    double input_values3_[13]  = {11274,11242,11163,11056,10968,10871,10694,10546,10397,10256,10152,10084,9960}; 
    double output_values3_[13] = {44.5,46.5,48.5,50.5,52.5,54.5,58.5,61.5,64.5,67.5,69.5,71,72.5};
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "interpolator_node");
    InterpolatorNode node;
    ros::spin();
    return 0;
}
