#include "ros/ros.h"
#include "std_msgs/Float64.h"

class Float64Publisher
{
public:
  Float64Publisher() : previous_reference_(0.0), v_max_(0.5), modify_references_(false) // Initialize previous_reference_, v_max_, and modify_references_
  {
    // Initialize ROS node handle
    nh_ = ros::NodeHandle("~");

    // Subscribe to the input topic
    input_sub_ = nh_.subscribe("/Referencia", 1, &Float64Publisher::inputCallback, this);

    // Advertise on the output topics
    referencia_pub1_ = nh_.advertise<std_msgs::Float64>("/Referencia_1", 1);
    referencia_pub2_ = nh_.advertise<std_msgs::Float64>("/Referencia_2", 1);
    referencia_pub3_ = nh_.advertise<std_msgs::Float64>("/Referencia_3", 1);
    referencia_pub4_ = nh_.advertise<std_msgs::Float64>("/Referencia_4", 1);

    // Initialize the array with publishers
    referencia_pubs_[0] = referencia_pub1_;
    referencia_pubs_[1] = referencia_pub2_;
    referencia_pubs_[2] = referencia_pub3_;
    referencia_pubs_[3] = referencia_pub4_;

    // Create a timer to publish references at 50Hz
    timer_ = nh_.createTimer(ros::Duration(0.05), &Float64Publisher::timerCallback, this);
  }

  // Callback function for the input topic
  void inputCallback(const std_msgs::Float64::ConstPtr &msg)
  {
    // Log a message
    // ROS_INFO("Input callback executed");

    // Check if the new reference is different from the previous one
    if (msg->data != current_reference_) {
      // Store the received reference
      current_reference_ = std::max(0.0, std::min(1.0, msg->data)); // Ensure the received reference stays within [0, 1]

      // Start modifying references
      modify_references_ = true;
    }
  }

  // Timer callback to publish references at 20Hz
  void timerCallback(const ros::TimerEvent&)
  {
    // Log a message
    // ROS_INFO("Timer callback executed");

    // Check if modification should continue
    if (!modify_references_) {
      return;
    }

    // Calculate the step size
    double step = v_max_ * 0.05; // 0.05 seconds corresponds to 20Hz

    // Calculate the direction of step
    double direction = (current_reference_ >= previous_reference_) ? 1.0 : -1.0;
      double reference = previous_reference_ + step * direction;
      reference = std::max(0.0, std::min(1.0, reference)); // Ensure the generated reference stays within [0, 1]

      // Check if modification should stop
      if ((direction > 0 && reference >= current_reference_) || (direction < 0 && reference <= current_reference_)) {
        reference = current_reference_;
        modify_references_ = false;
      } else
      {
        // Update previous_reference_ for the next iteration
        previous_reference_ = reference;
      }

      std_msgs::Float64 reference_msg;
      reference_msg.data = reference;

    // Generate references linearly between previous and received reference
    for (int i = 0; i < 4; ++i)
    {
      referencia_pubs_[i].publish(reference_msg);
    }
   
  }

private:
  ros::NodeHandle nh_;
  ros::Subscriber input_sub_;
  ros::Publisher referencia_pub1_;
  ros::Publisher referencia_pub2_;
  ros::Publisher referencia_pub3_;
  ros::Publisher referencia_pub4_;
  ros::Timer timer_;
  double previous_reference_;
  double current_reference_;
  double v_max_;
  bool modify_references_;
  ros::Publisher referencia_pubs_[4];
};

int main(int argc, char **argv)
{
  // Initialize ROS node
  ros::init(argc, argv, "float64_publisher");

  // Create an instance of the Float64Publisher class
  Float64Publisher float64_publisher;

  // Log a message
  ROS_INFO("Float64 publisher node initialized");

  // Spin ROS
  ros::spin();

  return 0;
}
